				<!-- user delete modal -->
					<div id="user_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Copy File?</h3>
					</div>
					<div class="modal-body">
				
										<center>
										<div class="control-group">
											
                                          <div class="controls">
										  	<input type="hidden" name="get_id" value="<?php echo $get_id; ?>">
                                        
									
                                          </div>
                                        </div>
										</center>
										

					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_user" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>