<div class="pull-right">
		<footer>
           <p>Programmed by: John Kevin Lorayna BSIS 4-A</p>
        <footer>
</div>